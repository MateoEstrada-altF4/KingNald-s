KINGNALD'S - PROYECTO UNIFICADO
================================

Proyecto principal:
kingnalds_codigo/Kingnalds_Unificado_v2/Kingnalds

Ejecución en NetBeans:
1. Abrir la carpeta del proyecto indicada arriba.
2. Usar JDK 21 (configuración original del proyecto).
3. Agregar el conector MySQL a Libraries si la ruta local no coincide.
4. Importar kingnalds_bd/kingnlads_bd.sql en MySQL.
5. Revisar usuario y contraseña de MySQL en src/ConexionDB/ConexionDB.java.
6. Ejecutar main.Main.

Contenido integrado:
- Inicio y navegación principal.
- Pantalla de carga animada con isotipo oficial.
- Login y gestión de usuarios existentes.
- Menú completo por categorías con buscador y carrito interactivo.
- Desayunos y almuerzos accesibles desde Inicio.
- Promociones del Reino.
- Historial y seguimiento de pedidos.
- Revisión, método de entrega, pago y confirmación de compra.
- Términos y condiciones.

Organización:
- src/kingnalds: interfaz y navegación del cliente.
- src/kingnalds/resources: recursos visuales optimizados.
- src/main: acceso y administración de usuarios.
- src/ConexionDB: conexión centralizada con MySQL.
- kingnalds_bd: script de base de datos.

Las carátulas del PDF fueron usadas únicamente como separadores de referencia y
no se añadieron como pantallas de la aplicación.
