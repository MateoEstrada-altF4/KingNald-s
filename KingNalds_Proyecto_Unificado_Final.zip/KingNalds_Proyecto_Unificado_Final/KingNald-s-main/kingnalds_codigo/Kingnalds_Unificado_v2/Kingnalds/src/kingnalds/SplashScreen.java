package kingnalds;

import java.awt.*;
import javax.swing.*;

/** Pantalla de carga con el isotipo oficial de la hamburguesa. */
public class SplashScreen extends JWindow {
    private final JProgressBar progress=new JProgressBar(0,100);
    public SplashScreen(Runnable done){JPanel root=new JPanel(new GridBagLayout());root.setBackground(new Color(5,5,4));root.setBorder(BorderFactory.createLineBorder(Theme.GOLD,2));GridBagConstraints c=new GridBagConstraints();c.gridx=0;c.insets=new Insets(8,25,8,25);ImageIcon raw=new ImageIcon(SplashScreen.class.getResource("/kingnalds/resources/isotipo.png"));Image scaled=raw.getImage().getScaledInstance(240,300,Image.SCALE_SMOOTH);c.gridy=0;root.add(new JLabel(new ImageIcon(scaled)),c);JLabel brand=new JLabel("KINGNALD'S");brand.setFont(Theme.serif(Font.PLAIN,32));brand.setForeground(Theme.GOLD_LIGHT);c.gridy=1;root.add(brand,c);JLabel sub=new JLabel("PREPARANDO TU EXPERIENCIA REAL");sub.setFont(Theme.sans(Font.BOLD,10));sub.setForeground(Theme.MUTED);c.gridy=2;root.add(sub,c);progress.setPreferredSize(new Dimension(330,7));progress.setBorderPainted(false);progress.setForeground(Theme.GOLD);progress.setBackground(new Color(35,29,20));c.gridy=3;root.add(progress,c);setContentPane(root);setSize(480,510);setLocationRelativeTo(null);Timer timer=new Timer(22,null);timer.addActionListener(e->{int value=progress.getValue()+2;progress.setValue(value);if(value>=100){timer.stop();dispose();done.run();}});timer.start();}
}
