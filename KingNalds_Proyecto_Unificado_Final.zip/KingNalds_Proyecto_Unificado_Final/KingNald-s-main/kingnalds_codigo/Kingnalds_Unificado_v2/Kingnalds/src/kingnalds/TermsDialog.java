package kingnalds;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Términos y condiciones mostrados como diálogo para no interrumpir el pedido. */
class TermsDialog extends JDialog {
    TermsDialog(Window owner){super(owner,"Términos y Condiciones",ModalityType.APPLICATION_MODAL);setSize(780,560);setLocationRelativeTo(owner);JPanel root=new JPanel(new BorderLayout(0,15));root.setBackground(Theme.BLACK);root.setBorder(new EmptyBorder(25,32,25,32));JLabel h=new JLabel("TÉRMINOS Y CONDICIONES");h.setFont(Theme.serif(Font.PLAIN,30));h.setForeground(Theme.IVORY);root.add(h,BorderLayout.NORTH);JTextArea text=new JTextArea("1. PEDIDOS Y DISPONIBILIDAD\nLos productos están sujetos a disponibilidad en cada sucursal.\n\n2. PRECIOS Y PAGOS\nTodos los precios se expresan en quetzales e incluyen impuestos.\n\n3. PROMOCIONES\nLas promociones no son acumulables y aplican durante el período indicado.\n\n4. ENTREGA Y RECOGIDA\nLos tiempos son estimados y pueden variar según la ubicación.\n\n5. PRIVACIDAD\nLa información del usuario se utiliza únicamente para gestionar sus pedidos.\n\n6. CAMBIOS Y RECLAMOS\nComunícate con la sucursal para resolver cualquier inconveniente.");text.setEditable(false);text.setLineWrap(true);text.setWrapStyleWord(true);text.setFont(Theme.sans(Font.PLAIN,14));text.setForeground(Theme.IVORY);text.setBackground(new Color(17,16,14));text.setBorder(new EmptyBorder(18,20,18,20));root.add(new JScrollPane(text),BorderLayout.CENTER);ModernButton accept=new ModernButton("ACEPTAR",true);accept.addActionListener(e->dispose());root.add(accept,BorderLayout.SOUTH);setContentPane(root);}
}
