package kingnalds;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Ofertas del Reino inspiradas en las páginas 11 a 15 del diseño. */
public class PromotionsFrame extends RoyalFrame {
    public PromotionsFrame(){super("Ofertas del Reino","PROMOCIONES");
        JPanel content=new JPanel();content.setOpaque(false);content.setLayout(new BoxLayout(content,BoxLayout.Y_AXIS));
        content.add(heading("OFERTAS DEL REINO"));content.add(muted("Promociones especiales preparadas para la casa real."));content.add(Box.createVerticalStrut(18));
        JPanel featured=new JPanel(new GridLayout(1,2,15,0));featured.setOpaque(false);featured.setMaximumSize(new Dimension(Integer.MAX_VALUE,220));
        featured.add(offer("FESTÍN DE LA CORONA","KingBurger, papas y bebida","Q59.00","/kingnalds/resources/products/combo-clasico.jpg"));
        featured.add(offer("BANQUETE DEL TRONO","Combo grande para compartir","Q84.00","/kingnalds/resources/products/banquete-real.jpg"));content.add(featured);content.add(Box.createVerticalStrut(15));
        JPanel grid=new JPanel(new GridLayout(1,3,12,0));grid.setOpaque(false);grid.add(offer("DESAYUNO DEL MONARCA","Disponible hasta las 11:00 AM","Q45.00","/kingnalds/resources/products/desayuno-del-rey.jpg"));grid.add(offer("BANQUETE REAL","Tres burgers y acompañamientos","Q149.00","/kingnalds/resources/menu/king-premium.png"));grid.add(offer("CORONA DULCE","Postre y café del reino","Q45.00","/kingnalds/resources/menu/tarta-manzana.png"));content.add(grid);body.add(content);
    }
    private JComponent offer(String name,String description,String price,String image){RoundedPanel card=new RoundedPanel(new Color(18,15,13),new Color(116,82,34));card.setLayout(new BorderLayout(12,8));card.setBorder(new EmptyBorder(12,14,12,14));ProductImage art=new ProductImage(image);art.setPreferredSize(new Dimension(180,125));card.add(art,BorderLayout.WEST);JLabel text=new JLabel("<html><span style='font-size:18px'>"+name+"</span><br><span style='color:#aaa59b;font-family:sans-serif'>"+description+"</span><br><br><span style='color:#e0b952;font-size:18px'>"+price+"</span></html>");text.setFont(Theme.serif(Font.PLAIN,16));text.setForeground(Theme.IVORY);card.add(text,BorderLayout.CENTER);ModernButton b=new ModernButton("ORDENAR",true);b.addActionListener(e->open(new MenuFrame()));card.add(b,BorderLayout.SOUTH);return card;}
}
