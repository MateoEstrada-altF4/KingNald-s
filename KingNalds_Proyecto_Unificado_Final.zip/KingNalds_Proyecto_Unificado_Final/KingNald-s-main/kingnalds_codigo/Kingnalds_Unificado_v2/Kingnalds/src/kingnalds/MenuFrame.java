package kingnalds;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Menú principal construido completamente con componentes Swing. */
public class MenuFrame extends JFrame {
    private final java.util.List<Product> products=Arrays.asList(
        new Product("Desayuno del Castillo","Huevos, pan artesanal y acompañamiento",42,"DESAYUNOS","/kingnalds/resources/products/desayuno-castillo.jpg"),
        new Product("Desayuno del Rey","Un desayuno completo digno de la corona",48,"DESAYUNOS","/kingnalds/resources/products/desayuno-del-rey.jpg"),
        new Product("Waffles de la Corona","Waffles dorados con fruta y miel",39,"DESAYUNOS","/kingnalds/resources/products/waffles-corona.jpg"),
        new Product("Muffin Real","Muffin de huevo, queso y carne",32,"DESAYUNOS","/kingnalds/resources/products/desayuno-del-rey.jpg"),
        new Product("Combo Clásico Real","Hamburguesa, papas y bebida",59,"COMBOS REALES","/kingnalds/resources/products/muffin-real.jpg"),
        new Product("Combo Crispy","Pollo crujiente, papas y bebida",64,"COMBOS REALES","/kingnalds/resources/products/cafe-real.jpg"),
        new Product("Banquete Real","El combo grande para compartir",89,"COMBOS REALES","/kingnalds/resources/products/avena-corona.jpg"),
        new Product("King Clásica","Carne a la parrilla y queso real",45,"HAMBURGUESAS","/kingnalds/resources/products/combo-clasico.jpg"),
        new Product("Doble Corona","Doble carne, doble queso y salsa de la casa",58,"HAMBURGUESAS","/kingnalds/resources/products/combo-crispy.jpg"),
        new Product("Nuggets de la Corona","Nuggets dorados con salsa a elegir",38,"POLLO & NUGGETS","/kingnalds/resources/products/king-clasica.jpg"),
        new Product("Pollo Real","Piezas de pollo crujiente",52,"POLLO & NUGGETS","/kingnalds/resources/products/doble-corona.jpg"),
        new Product("Tiras Reales","Tiras de pollo con aderezo",46,"POLLO & NUGGETS","/kingnalds/resources/products/bbq-real.jpg"),
        new Product("Papas del Reino","Papas clásicas con sal real",22,"ACOMPAÑAMIENTOS","/kingnalds/resources/products/nuggets-corona.jpg"),
        new Product("Aros Dorados","Aros de cebolla crujientes",28,"ACOMPAÑAMIENTOS","/kingnalds/resources/products/pollo-real.jpg"),
        new Product("Ensalada Real","Vegetales frescos y aderezo",30,"ACOMPAÑAMIENTOS","/kingnalds/resources/products/tiras-reales.jpg"),
        new Product("Lemon King","Bebida fría con limón natural",25,"BEBIDAS","/kingnalds/resources/menu/lemon-king.png"),
        new Product("Cola King","Refresco frío de la casa",15,"BEBIDAS","/kingnalds/resources/menu/cola-king.png"),
        new Product("King Premium","Hamburguesa premium, papas y bebida",99,"COMBOS REALES","/kingnalds/resources/menu/king-premium.png"),
        new Product("Tarta de Manzana","Tarta artesanal acompañada con helado",35,"POSTRES","/kingnalds/resources/menu/tarta-manzana.png"),
        new Product("Churros del Castillo","Churros con nuestro complemento especial",45,"POSTRES","/kingnalds/resources/menu/churros-castillo.png"),
        new Product("KingBurger BBQ Real","Hamburguesa BBQ premium con cheddar",75,"HAMBURGUESAS","/kingnalds/resources/menu/kingburger-bbq.png")
    );
    private final Map<Product,Integer> cart=new LinkedHashMap<Product,Integer>();
    private final JPanel grid=new JPanel(new GridLayout(0,3,10,10));
    private final JPanel cartList=new JPanel();
    private final JLabel subtotal=new JLabel("Q0.00",SwingConstants.RIGHT);
    private final JLabel total=new JLabel("Q0.00",SwingConstants.RIGHT);
    private final JLabel cartCount=new JLabel("0");
    private final JTextField search=new JTextField();
    private String category="TODOS";

    public MenuFrame(){this("TODOS");}
    public MenuFrame(String initialCategory){
        category=initialCategory==null?"TODOS":initialCategory;
        setTitle("KINGNALD'S — Elige tu banquete");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1120,680));
        setSize(1500,850);
        setLocationRelativeTo(null);
        JPanel root=new JPanel(new BorderLayout());root.setBackground(new Color(7,7,6));setContentPane(root);
        root.add(header(),BorderLayout.NORTH);
        JPanel body=new JPanel(new BorderLayout(14,0));body.setOpaque(false);body.setBorder(new EmptyBorder(14,30,18,30));
        body.add(catalog(),BorderLayout.CENTER);body.add(cartPanel(),BorderLayout.EAST);root.add(body,BorderLayout.CENTER);
        refreshProducts();refreshCart();
    }

    private JComponent header(){
        JPanel p=new JPanel(new BorderLayout(18,0));p.setBackground(new Color(8,8,7));p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(82,61,30)),new EmptyBorder(12,32,10,32)));
        JLabel logo=new JLabel("<html><span style='font-size:23px'>KINGNALD'S</span><br><span style='font-family:sans-serif;font-size:8px'>ROYAL BURGER HOUSE</span></html>",new VectorIcon(VectorIcon.Type.CROWN,28,Theme.GOLD),JLabel.LEFT);logo.setIconTextGap(10);logo.setFont(Theme.serif(Font.PLAIN,21));logo.setForeground(Theme.IVORY);p.add(logo,BorderLayout.WEST);
        JPanel nav=new JPanel(new FlowLayout(FlowLayout.CENTER,7,0));nav.setOpaque(false);
        nav.add(navButton("INICIO",VectorIcon.Type.HOME,()->{new InicioFrame().setVisible(true);dispose();},false));
        nav.add(navButton("MENÚ",VectorIcon.Type.MENU,()->{},true));
        nav.add(navButton("PROMOCIONES",VectorIcon.Type.TAG,()->{new PromotionsFrame().setVisible(true);dispose();},false));
        nav.add(navButton("MIS PEDIDOS",VectorIcon.Type.BAG,()->{new OrdersFrame().setVisible(true);dispose();},false));
        nav.add(navButton("MÁS",VectorIcon.Type.MORE,()->new TermsDialog(this).setVisible(true),false));p.add(nav,BorderLayout.CENTER);
        JPanel badge=new JPanel(new FlowLayout(FlowLayout.RIGHT,5,0));badge.setOpaque(false);JLabel icon=new JLabel(new VectorIcon(VectorIcon.Type.CART,25,Theme.GOLD));cartCount.setFont(Theme.sans(Font.BOLD,12));cartCount.setForeground(Color.WHITE);cartCount.setOpaque(true);cartCount.setBackground(new Color(125,25,28));cartCount.setBorder(new EmptyBorder(3,7,3,7));badge.add(icon);badge.add(cartCount);p.add(badge,BorderLayout.EAST);return p;
    }

    private JButton navButton(String text,VectorIcon.Type type,Runnable action,boolean active){ModernButton b=new ModernButton(text,false);b.setIcon(new VectorIcon(type,17,active?Theme.GOLD:Theme.MUTED));b.setForeground(active?Theme.GOLD_LIGHT:Theme.MUTED);b.addActionListener(e->action.run());return b;}

    private JComponent catalog(){
        JPanel outer=new JPanel(new BorderLayout(0,10));outer.setOpaque(false);
        JPanel intro=new JPanel(new BorderLayout(15,4));intro.setOpaque(false);
        JPanel titleBox=new JPanel();titleBox.setOpaque(false);titleBox.setLayout(new BoxLayout(titleBox,BoxLayout.Y_AXIS));JLabel title=new JLabel("ELIGE TU BANQUETE");title.setFont(Theme.serif(Font.PLAIN,32));title.setForeground(Theme.IVORY);JLabel sub=new JLabel("Sabores dignos de la corona, preparados para ti.");sub.setFont(Theme.sans(Font.PLAIN,12));sub.setForeground(Theme.MUTED);titleBox.add(title);titleBox.add(sub);intro.add(titleBox,BorderLayout.WEST);
        JPanel find=new JPanel(new BorderLayout(8,0));find.setOpaque(false);search.setPreferredSize(new Dimension(280,38));search.setBackground(new Color(19,18,16));search.setForeground(Theme.IVORY);search.setCaretColor(Theme.GOLD);search.setFont(Theme.sans(Font.PLAIN,12));search.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(109,80,38)),new EmptyBorder(7,12,7,12)));search.putClientProperty("JTextField.placeholderText","Buscar en el menú...");search.getDocument().addDocumentListener(new DocumentListener(){public void insertUpdate(DocumentEvent e){refreshProducts();}public void removeUpdate(DocumentEvent e){refreshProducts();}public void changedUpdate(DocumentEvent e){refreshProducts();}});find.add(search,BorderLayout.CENTER);ModernButton filter=new ModernButton("FILTROS",false);filter.setIcon(new VectorIcon(VectorIcon.Type.MENU,16,Theme.GOLD));filter.addActionListener(e->message("Selecciona una categoría para filtrar los productos"));find.add(filter,BorderLayout.EAST);intro.add(find,BorderLayout.EAST);outer.add(intro,BorderLayout.NORTH);
        JPanel center=new JPanel(new BorderLayout(0,8));center.setOpaque(false);center.add(categories(),BorderLayout.NORTH);grid.setOpaque(false);JScrollPane scroll=new JScrollPane(grid);scroll.setOpaque(false);scroll.getViewport().setOpaque(false);scroll.setBorder(null);scroll.getVerticalScrollBar().setUnitIncrement(18);center.add(scroll,BorderLayout.CENTER);outer.add(center,BorderLayout.CENTER);return outer;
    }

    private JComponent categories(){
        JPanel wrap=new JPanel();wrap.setOpaque(false);wrap.setLayout(new BoxLayout(wrap,BoxLayout.Y_AXIS));JPanel row=new JPanel(new GridLayout(1,8,5,0));row.setOpaque(false);
        String[] names={"TODOS","DESAYUNOS","COMBOS REALES","HAMBURGUESAS","POLLO & NUGGETS","ACOMPAÑAMIENTOS","BEBIDAS","POSTRES"};VectorIcon.Type[] icons={VectorIcon.Type.CROWN,VectorIcon.Type.COFFEE,VectorIcon.Type.SHARE,VectorIcon.Type.BURGER,VectorIcon.Type.BAG,VectorIcon.Type.MENU,VectorIcon.Type.COFFEE,VectorIcon.Type.CROWN};
        for(int i=0;i<names.length;i++){final String name=names[i];ModernButton b=new ModernButton(name,false);b.setIcon(new VectorIcon(icons[i],16,Theme.GOLD));b.setFont(Theme.sans(Font.BOLD,9));b.addActionListener(e->{category=name;refreshProducts();});row.add(b);}wrap.add(row);JLabel schedule=new JLabel("Desayunos hasta las 11:00 AM   •   Almuerzos y cenas desde las 12:00 PM",SwingConstants.CENTER);schedule.setForeground(Theme.MUTED);schedule.setFont(Theme.sans(Font.PLAIN,10));schedule.setBorder(new EmptyBorder(7,0,2,0));schedule.setAlignmentX(Component.CENTER_ALIGNMENT);wrap.add(schedule);return wrap;
    }

    private void refreshProducts(){
        grid.removeAll();String term=search.getText().trim().toLowerCase(Locale.ROOT);int shown=0;
        for(Product p:products)if((category.equals("TODOS")||p.category.equals(category))&&(term.isEmpty()||p.name.toLowerCase(Locale.ROOT).contains(term)||p.description.toLowerCase(Locale.ROOT).contains(term))){grid.add(new ProductCard(p));shown++;}
        if(shown==0){JLabel none=new JLabel("No encontramos productos en esta categoría",SwingConstants.CENTER);none.setForeground(Theme.MUTED);none.setFont(Theme.serif(Font.PLAIN,18));grid.add(none);}
        grid.revalidate();grid.repaint();
    }

    private JComponent cartPanel(){
        RoundedPanel card=new RoundedPanel(new Color(42,9,11),new Color(137,38,36));card.setPreferredSize(new Dimension(335,600));card.setLayout(new BorderLayout(0,8));card.setBorder(new EmptyBorder(17,20,18,20));
        JLabel head=new JLabel("<html><center><span style='font-size:13px'>♛</span><br><span style='font-size:24px'>TU BANQUETE</span></center></html>",SwingConstants.CENTER);head.setFont(Theme.serif(Font.PLAIN,22));head.setForeground(Theme.GOLD_LIGHT);card.add(head,BorderLayout.NORTH);
        cartList.setOpaque(false);cartList.setLayout(new BoxLayout(cartList,BoxLayout.Y_AXIS));JScrollPane scroll=new JScrollPane(cartList);scroll.setOpaque(false);scroll.getViewport().setOpaque(false);scroll.setBorder(null);scroll.getVerticalScrollBar().setUnitIncrement(16);card.add(scroll,BorderLayout.CENTER);
        JPanel totals=new JPanel();totals.setOpaque(false);totals.setLayout(new BoxLayout(totals,BoxLayout.Y_AXIS));totals.add(totalRow("SUBTOTAL",subtotal));totals.add(Box.createVerticalStrut(6));totals.add(totalRow("TOTAL",total));totals.add(Box.createVerticalStrut(12));ModernButton review=new ModernButton("REVISAR PEDIDO",true);review.setAlignmentX(Component.CENTER_ALIGNMENT);review.setMaximumSize(new Dimension(Integer.MAX_VALUE,46));review.addActionListener(e->{if(cart.isEmpty())message("Tu banquete está vacío. Agrega un producto para continuar.");else new CheckoutDialog(this,cartCount.getText(),total.getText()).setVisible(true);});totals.add(review);ModernButton clear=new ModernButton("VACIAR CARRITO",false);clear.setAlignmentX(Component.CENTER_ALIGNMENT);clear.addActionListener(e->{cart.clear();refreshCart();});totals.add(clear);card.add(totals,BorderLayout.SOUTH);return card;
    }

    private JPanel totalRow(String text,JLabel amount){JPanel p=new JPanel(new BorderLayout());p.setOpaque(false);JLabel l=new JLabel(text);l.setForeground(Theme.IVORY);l.setFont(Theme.sans(Font.BOLD,text.equals("TOTAL")?14:11));amount.setForeground(Theme.GOLD_LIGHT);amount.setFont(Theme.serif(Font.PLAIN,text.equals("TOTAL")?24:16));p.add(l,BorderLayout.WEST);p.add(amount,BorderLayout.EAST);return p;}

    private void add(Product p){cart.put(p,cart.containsKey(p)?cart.get(p)+1:1);refreshCart();}
    private void refreshCart(){
        cartList.removeAll();int units=0;double sum=0;
        if(cart.isEmpty()){JLabel empty=new JLabel("<html><center><span style='font-size:18px'>Tu banquete está vacío</span><br><br><span style='color:#a99c91'>Selecciona un producto del menú<br>para comenzar tu pedido.</span></center></html>",SwingConstants.CENTER);empty.setFont(Theme.serif(Font.PLAIN,14));empty.setForeground(Theme.IVORY);empty.setAlignmentX(Component.CENTER_ALIGNMENT);empty.setBorder(new EmptyBorder(65,5,10,5));cartList.add(empty);}
        for(Map.Entry<Product,Integer> e:cart.entrySet()){units+=e.getValue();sum+=e.getKey().price*e.getValue();cartList.add(new CartItem(e.getKey(),e.getValue()));cartList.add(Box.createVerticalStrut(7));}
        cartCount.setText(String.valueOf(units));subtotal.setText(String.format(Locale.US,"Q%.2f",sum));total.setText(String.format(Locale.US,"Q%.2f",sum));cartList.revalidate();cartList.repaint();
    }

    private void message(String s){JOptionPane.showMessageDialog(this,s,"KINGNALD'S",JOptionPane.INFORMATION_MESSAGE);}

    private class ProductCard extends RoundedPanel{
        ProductCard(Product p){super(new Color(17,16,14),new Color(91,68,34));setLayout(new BorderLayout(0,5));setBorder(new EmptyBorder(7,10,9,10));ProductPhoto photo=new ProductPhoto(p.image);photo.setPreferredSize(new Dimension(230,160));add(photo,BorderLayout.CENTER);JPanel info=new JPanel(new BorderLayout(5,2));info.setOpaque(false);JLabel copy=new JLabel("<html><span style='font-size:15px'>"+p.name+"</span><br><span style='color:#aaa59b;font-family:sans-serif;font-size:9px'>"+p.description+"</span><br><span style='color:#e0b952;font-size:15px'>Q"+String.format(Locale.US,"%.2f",p.price)+"</span></html>");copy.setFont(Theme.serif(Font.PLAIN,14));copy.setForeground(Theme.IVORY);info.add(copy,BorderLayout.CENTER);ModernButton addButton=new ModernButton("AGREGAR",true);addButton.addActionListener(e->MenuFrame.this.add(p));info.add(addButton,BorderLayout.EAST);this.add(info,BorderLayout.SOUTH);}
    }

    private class CartItem extends RoundedPanel{
        CartItem(Product p,int qty){super(new Color(28,11,11),new Color(92,48,33));setMaximumSize(new Dimension(Integer.MAX_VALUE,102));setLayout(new BorderLayout(8,0));setBorder(new EmptyBorder(7,7,7,7));ProductPhoto photo=new ProductPhoto(p.image);photo.setPreferredSize(new Dimension(78,76));add(photo,BorderLayout.WEST);JPanel info=new JPanel();info.setOpaque(false);info.setLayout(new BoxLayout(info,BoxLayout.Y_AXIS));JLabel name=new JLabel(p.name);name.setForeground(Theme.IVORY);name.setFont(Theme.serif(Font.PLAIN,14));JLabel price=new JLabel(String.format(Locale.US,"Q%.2f",p.price*qty));price.setForeground(Theme.GOLD_LIGHT);price.setFont(Theme.sans(Font.BOLD,11));JPanel controls=new JPanel(new FlowLayout(FlowLayout.LEFT,2,0));controls.setOpaque(false);ModernButton minus=new ModernButton("−",false);minus.addActionListener(e->{if(qty<=1)cart.remove(p);else cart.put(p,qty-1);refreshCart();});JLabel q=new JLabel("  "+qty+"  ");q.setForeground(Theme.IVORY);ModernButton plus=new ModernButton("+",false);plus.addActionListener(e->{cart.put(p,qty+1);refreshCart();});ModernButton remove=new ModernButton("×",false);remove.addActionListener(e->{cart.remove(p);refreshCart();});controls.add(minus);controls.add(q);controls.add(plus);controls.add(remove);info.add(name);info.add(price);info.add(controls);add(info,BorderLayout.CENTER);}
    }

    private static class ProductPhoto extends JComponent{
        private BufferedImage image;ProductPhoto(String path){try{image=ImageIO.read(ProductPhoto.class.getResource(path));}catch(IOException|IllegalArgumentException ex){image=null;}setOpaque(false);}
        protected void paintComponent(Graphics raw){Graphics2D g=(Graphics2D)raw.create();g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);g.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);Shape old=g.getClip();g.clip(new RoundRectangle2D.Float(0,0,getWidth(),getHeight(),12,12));if(image!=null){int cropH=Math.max(1,(int)(image.getHeight()*.66));double scale=Math.max((double)getWidth()/image.getWidth(),(double)getHeight()/cropH);int w=(int)(image.getWidth()*scale),h=(int)(cropH*scale);g.drawImage(image,(getWidth()-w)/2,(getHeight()-h)/2,w,h,null);}else{g.setColor(new Color(30,27,22));g.fillRect(0,0,getWidth(),getHeight());}g.setClip(old);g.dispose();}
    }

    private static class Product{final String name,description,category,image;final double price;Product(String n,String d,double p,String c,String i){name=n;description=d;price=p;category=c;image=i;}}
    
    public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        MenuFrame menuPrincipal = new MenuFrame();
        menuPrincipal.setVisible(true);
    });
}
}
