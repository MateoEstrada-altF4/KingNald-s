package kingnalds;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Base visual compartida para mantener navegación y estilo consistentes. */
abstract class RoyalFrame extends JFrame {
    protected final JPanel body=new JPanel(new BorderLayout());

    RoyalFrame(String title,String active){
        setTitle("KINGNALD'S - "+title);setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1050,650));setSize(1366,768);setLocationRelativeTo(null);
        JPanel root=new JPanel(new BorderLayout());root.setBackground(Theme.BLACK);setContentPane(root);
        root.add(header(active),BorderLayout.NORTH);body.setOpaque(false);body.setBorder(new EmptyBorder(25,45,30,45));root.add(body,BorderLayout.CENTER);
    }

    private JComponent header(String active){
        JPanel p=new JPanel(new BorderLayout(15,0));p.setBackground(new Color(8,8,7));p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(92,70,36)),new EmptyBorder(10,30,10,30)));
        JLabel logo=new JLabel("<html><span style='font-size:22px'>KINGNALD'S</span><br><span style='font-family:sans-serif;font-size:8px'>ROYAL BURGER HOUSE</span></html>",new VectorIcon(VectorIcon.Type.CROWN,27,Theme.GOLD),JLabel.LEFT);logo.setForeground(Theme.IVORY);logo.setFont(Theme.serif(Font.PLAIN,20));logo.setIconTextGap(10);p.add(logo,BorderLayout.WEST);
        JPanel nav=new JPanel(new FlowLayout(FlowLayout.CENTER,5,0));nav.setOpaque(false);
        addNav(nav,"INICIO",active,()->open(new InicioFrame()));addNav(nav,"MENÚ",active,()->open(new MenuFrame()));addNav(nav,"PROMOCIONES",active,()->open(new PromotionsFrame()));addNav(nav,"MIS PEDIDOS",active,()->open(new OrdersFrame()));
        ModernButton more=new ModernButton("MÁS",false);more.addActionListener(e->new TermsDialog(this).setVisible(true));nav.add(more);p.add(nav,BorderLayout.CENTER);
        JLabel crown=new JLabel(new VectorIcon(VectorIcon.Type.CART,24,Theme.GOLD));p.add(crown,BorderLayout.EAST);return p;
    }

    private void addNav(JPanel p,String name,String active,Runnable action){ModernButton b=new ModernButton(name,false);b.setForeground(name.equals(active)?Theme.GOLD_LIGHT:Theme.MUTED);b.addActionListener(e->action.run());p.add(b);}
    protected void open(JFrame next){next.setVisible(true);dispose();}
    protected JLabel heading(String text){JLabel l=new JLabel(text);l.setFont(Theme.serif(Font.PLAIN,34));l.setForeground(Theme.IVORY);return l;}
    protected JLabel muted(String text){JLabel l=new JLabel(text);l.setFont(Theme.sans(Font.PLAIN,12));l.setForeground(Theme.MUTED);return l;}
}
